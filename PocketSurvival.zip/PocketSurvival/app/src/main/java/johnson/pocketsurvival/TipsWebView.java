package johnson.pocketsurvival;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.Toast;

public class TipsWebView extends AppCompatActivity {
    private ImageButton btnDownload;
    String URL = "https://raw.githubusercontent.com/PocketSurvival/PocketSurvival/master/KJAG9Lw.jpg";
    String filename = "DOWNLOADS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips_web_view);

        btnDownload = (ImageButton) findViewById(R.id.download_button);

        WebView webView = (WebView) findViewById(R.id.webview);
        //webView.setUseWideViewPort();
        webView.setInitialScale(150);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.loadUrl("https://raw.githubusercontent.com/PocketSurvival/PocketSurvival/master/KJAG9Lw.jpg");
    }
}
/*
    private download(){
        AsyncTask fileTask = new AsyncTask() {
            @Override
            protected Object doInBackground(Object[] objects) {
                File directory = new File(Environment.getExternalStorageDirectory() + File.separator + "MyApplication");
                if (!directory.exists()) {
                    directory.mkdirs();
                }
                Random generator = new Random();
                int n = 10000;
                n = generator.nextInt(n);
                String name = " "+n+".jpg";
                File pictureFile = new File(directory, name);
                try {
                    pictureFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    FileOutputStream out = new FileOutputStream(pictureFile);
                    finalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                    out.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        fileTask.execute();
    }
    */

