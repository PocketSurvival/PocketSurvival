package johnson.pocketsurvival;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.jar.Manifest;

public class MainActivity extends AppCompatActivity {
    private String[] categories;
    private DrawerLayout drawerLayout;
    private ListView drawerList;
    private ListView tipsList;
    //private List<String> listItems = Arrays.asList(getResources().getStringArray(R.array.tips));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //categories = getResources().getStringArray();
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawerList = (ListView) findViewById(R.id.left_drawer);

        //Set adapter for the list view
        //drawerList.setAdapter(new ArrayAdapter<String>(this, R.layout.drawer_list_item, categories));
        //Set the onClickListener
       // drawerList.setOnItemClickListener(new DrawerItemClickListener);

        //ArrayAdapter<String> listViewAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems);
        tipsList = (ListView)findViewById(R.id.tips_list);
        //tipsList.setAdapter(listViewAdapter);
        tipsList.setClickable(true);
         tipsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                Intent intent = new Intent(MainActivity.this, TipsWebView.class);
                startActivity(intent);
            }
        });

        //Intent intent = new Intent(this, TipsWebView.class);
        //startActivity(intent);
    }
}
